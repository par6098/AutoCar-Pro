export type UserRole = 'ADMIN' | 'EMPLOYEE' | 'CUSTOMER';

export type LoginRequest = {
  email: string;
  password: string;
  role: UserRole;
};

export type RegisterRequest = {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
};